package com.cg.SpringBoot.bean;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

@Entity
public class Products {

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="seqId")
    @SequenceGenerator(name="seqId", initialValue=1001, sequenceName = "prod_id")
    @Column(name="id", updatable=false, nullable=false)

	private long id;
	private String name;
	private String model;
	@Min(5000)
	@Max(100000)
	private long price;
	private int quantity;
	private long total_price;
	

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public long getPrice() {
		return price;
	}

	public void setPrice(long price) {
		this.price = price;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public long getTotal_price() {
		return total_price;
	}

	public void setTotal_price(long total_price) {
		this.total_price = total_price;
	}
}
//@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "product_generator") 
//@SequenceGenerator(name="product_generator", sequenceName = "product_seq") 
//@Column(name = "id", updatable = false, nullable = false)