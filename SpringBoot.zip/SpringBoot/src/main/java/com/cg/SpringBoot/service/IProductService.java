package com.cg.SpringBoot.service;

import java.util.List;

import com.cg.SpringBoot.bean.Products;
public interface IProductService {

	public List<Products> addProduct(Products pro);
	public Products getProductById(long id);
	public void deleteProduct (long id);
	public List<Products> getAllProducts();
	public List<Products> updateProduct(long id, Products bo);
	

}
