package com.cg.SpringBoot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.SpringBoot.bean.Products;
import com.cg.SpringBoot.service.IProductService;

@RestController
public class ProductController {

	@Autowired
	IProductService productService;

	@RequestMapping("/products")
	public List<Products> getAllProducts() {
		return productService.getAllProducts();
	}

	@RequestMapping(value = "/product", method = RequestMethod.POST)
	public List<Products> addProduct(@RequestBody Products pro) {
		return productService.addProduct(pro);
	}

	@RequestMapping("/products/{id}")
	public Products getProductById(@PathVariable long id) {
		return productService.getProductById(id);
	}

	@DeleteMapping("/products/{id}")
	public ResponseEntity<String> deleteProduct(@PathVariable long id) {
		productService.deleteProduct(id);
		return new ResponseEntity<String>("Product with id " + id + " deleted successfullyy", HttpStatus.OK);
	}

	@PutMapping("/products/{id}")
	public List<Products> updateProduct(@PathVariable long id, @RequestBody Products pro) {
		return productService.updateProduct(id, pro);
	}

}
