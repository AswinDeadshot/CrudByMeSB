package com.cg.SpringBoot.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.SpringBoot.bean.Products;
import com.cg.SpringBoot.dao.IProductDAO;

@Service
public class ProductServiceIMPL implements IProductService {

	@Autowired
	IProductDAO productDAO;

	@Override
	public List<Products> addProduct(Products pro) {
		long price = pro.getPrice() * pro.getQuantity();
		pro.setTotal_price(price);
		productDAO.save(pro);
		return productDAO.findAll();
	}

	@Override
	public Products getProductById(long id) {

		return productDAO.findById(id).get();
	}

	@Override
	public List<Products> getAllProducts() {

		return productDAO.findAll();
	}

	@Override
	public void deleteProduct(long id) {

		productDAO.deleteById(id);

	}

	@Override
	public List<Products> updateProduct(long id, Products bo) {

		Optional<Products> optional = productDAO.findById(id);
		if (optional.isPresent()) {
			Products product = optional.get();
			product.setName(bo.getName());
			product.setModel(bo.getModel());
			product.setPrice(bo.getPrice());
			product.setQuantity(bo.getQuantity());
			product.setTotal_price(bo.getPrice() * bo.getQuantity());
			productDAO.save(product);
			return getAllProducts();
		} else {
			System.out.println("no data found");
			return null;

		}
	}
}
